import numpy as np
import matplotlib.pyplot as plt

# Loads data from file with year and rainfall columns
def Load_Data(file_name):
    data = np.loadtxt(file_name, dtype={'names': ('year', 'rainfall'), 'formats': ('U10', 'f4')})
    return data

# Plots line graph comparing two data sets and saves as png file
def Compare_Sets(set1, set2):
    fig, ax = plt.subplots(figsize=(8, 8))  # Adjust the figure size as desired
    ax.plot(set1['year'], set1['rainfall'], label='Set1')
    ax.plot(set2['year'], set2['rainfall'], label='Set2')
    plt.xticks(rotation=45, ha='right')
    plt.title('Comparison of Set1 and Set2')
    ax.set_ylabel('Rainfall (inches)')
    ax.legend()
    plt.savefig('Set_Comparison.png')

# Plots Set1 and Set2 on separate subplots in one figure and saves as png file
def Combined_Plot(set1, set2):
    fig, axs = plt.subplots(nrows=2, ncols=1, figsize=(12, 10))

    # Plots Set1 data
    axs[0].plot(set1['year'], set1['rainfall'], label='Rainfall')
    axs[0].set_ylabel('Rainfall (inches)')
    axs[0].set_title('Set1 Data')
    axs[0].tick_params(axis='x', labelrotation=45, pad=15) # Add spacing and rotate x labels
    set1_max = round(set1['rainfall'].max(), 3) # Rounds max value for Set1
    set1_min = round(set1['rainfall'].min(), 3) # Rounds min value for Set1
    set1_max_coord = f"({set1['year'][np.argmax(set1['rainfall'])]}, {set1_max:.3f})"
    set1_min_coord = f"({set1['year'][np.argmin(set1['rainfall'])]}, {set1_min:.3f})"
    axs[0].scatter(set1['year'][np.argmax(set1['rainfall'])], set1_max, c='r', s=100, label=f"Max value: {set1_max_coord}")
    axs[0].scatter(set1['year'][np.argmin(set1['rainfall'])], set1_min, c='g', s=100, label=f"Min value: {set1_min_coord}")
    axs[0].legend()

    # Plots Set2 data
    axs[1].plot(set2['year'], set2['rainfall'], label='Rainfall')
    axs[1].set_ylabel('Rainfall (inches)')
    axs[1].set_title('Set2 Data')
    axs[1].tick_params(axis='x', labelrotation=45, pad=15) # Adds spacing and rotate x labels
    set2_max = round(set2['rainfall'].max(), 3) # Rounds max value for Set2
    set2_min = round(set2['rainfall'].min(), 3) # Rounds min value for Set2
    set2_max_coord = f"({set2['year'][np.argmax(set2['rainfall'])]}, {set2_max:.3f})"
    set2_min_coord = f"({set2['year'][np.argmin(set2['rainfall'])]}, {set2_min:.3f})"
    axs[1].scatter(set2['year'][np.argmax(set2['rainfall'])], set2_max, c='r', s=100, label=f"Max value: {set2_max_coord}")
    axs[1].scatter(set2['year'][np.argmin(set2['rainfall'])], set2_min, c='g', s=100, label=f"Min value: {set2_min_coord}")
    axs[1].legend()

    # Adjusts Plot
    plt.subplots_adjust(hspace=0.445)
    plt.savefig('Set1_Set2_Subplots_MinMax.png')

def main():
    set1 = Load_Data('Set1.txt')
    set2 = Load_Data('Set2.txt')

    # Calls function to compare data sets through line graph
    Compare_Sets(set1, set2)
    
    # Calls function to plot data on subplots and saves figure
    Combined_Plot(set1, set2)
    
    # Creates bar chart comparing Set1 and Set2 (additional data visualization)
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.bar(set1['year'], set1['rainfall'], label='Set1', color='b', alpha=0.5)
    ax.bar(set2['year'], set2['rainfall'], label='Set2', color='r', alpha=0.5)
    ax.set_ylabel('Rainfall (inches)')
    ax.set_title('Set1 vs Set2')
    ax.tick_params(axis='x', labelrotation=45, pad=15)
    ax.legend()
    # Saves Bar Chart
    plt.savefig('Set1_Set2_BarChart.png')
main()